<?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">ajouter un client</div>

                <div class="panel-body">
                    <?php echo Form::open(['url' => route('clients.store')]); ?>

                          <div class="form-group">
                             <?php echo Form::label('nom','nom'); ?>

                             <?php echo Form::text('nom',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('prenom','prenom'); ?>

                             <?php echo Form::text('prenom',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('adresse','adresse'); ?>

                             <?php echo Form::text('adresse',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('telephone','telephone'); ?>

                             <?php echo Form::text('telephone',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('email','email'); ?>

                             <?php echo Form::text('email',null, ['class' => 'form-control']); ?>

                          </div>
                          <button class="btn btn-primary">envoyer</button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>