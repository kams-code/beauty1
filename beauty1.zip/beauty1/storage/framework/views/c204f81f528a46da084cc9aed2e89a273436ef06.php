<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">ajouter une organisation</div>

                <div class="panel-body">
                    <?php echo Form::open(['url' => route('organisations.store')]); ?>

                          <div class="form-group">
                             <?php echo Form::label('nom','nom'); ?>

                             <?php echo Form::text('nom',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('pays','pays'); ?>

                             <?php echo Form::text('pays',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('ville','ville'); ?>

                             <?php echo Form::text('ville',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('adresse','adresse'); ?>

                             <?php echo Form::text('adresse',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('telephone','telephone'); ?>

                             <?php echo Form::text('telephone',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('description','description'); ?>

                             <?php echo Form::textarea('description',null, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                          <label>
                             <?php echo Form::checkbox('online'); ?>

                             en ligne?
                             </label> 
                          </div>
                          <button class="btn btn-primary">envoyer</button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>