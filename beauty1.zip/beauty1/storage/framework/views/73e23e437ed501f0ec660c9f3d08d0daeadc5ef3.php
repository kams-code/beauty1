<?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                 <?php $__env->startSection('content'); ?>
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_produits', 'delete_produits')): ?>
                    <footer class="footer text-right">
                    2016 © Moltran.
                </footer>
                <?php endif; ?>
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_produits', 'delete_produits')): ?>
                  
  <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="pull-left page-title">Produits</h4>
                                <ol class="breadcrumb pull-right">
                                    <li><a href="#">Moltran</a></li>
                                    <li><a href="#">Tables</a></li>
                                    <li class="active">Editer produits</li>
                                </ol>
                            </div>
                        </div>


                        <div class="panel">
                            
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="m-b-30">
                                        <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none">
                                            <div class="modal-dialog"> 
                                                <div class="modal-content"> 
                                                    <div class="modal-header"> 
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
                                                        <h4 class="modal-title">Modal Content is Responsive</h4> 
                                                    </div> 
                                                    <div class="modal-body"> 
                                                        <div class="row"> 
                                                             <?php echo Form::open(['class' => 'form-horizontal','role' => 'form','url' => route('organisations.store')]); ?>

                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-3 control-label"><?php echo Form::label('nom','Nom'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('nom',null, ['class' => 'form-control']); ?>

                                                 </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputPassword3" class="col-sm-3 control-label"><?php echo Form::label('pays','Pays'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('pays',null, ['class' => 'form-control']); ?>

          </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputPassword3" class="col-sm-3 control-label"><?php echo Form::label('ville','Ville'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('ville',null, ['class' => 'form-control']); ?>

          </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputPassword3" class="col-sm-3 control-label"><?php echo Form::label('adresse','Adresse'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('adresse',null, ['class' => 'form-control']); ?>

          </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword3" class="col-sm-3 control-label"><?php echo Form::label('telephone','Telephone'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('telephone',null, ['class' => 'form-control']); ?>

          </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="inputPassword3" class="col-sm-3 control-label"><?php echo Form::label('description','Description'); ?></label>
                                                <div class="col-sm-9">
                                                  <?php echo Form::text('description',null, ['class' => 'form-control']); ?>

          </div>
                                            </div>
                                            
                                           
                                            <div class="form-group m-b-0">
                                                <div class="col-sm-offset-3 col-sm-9">
                                                
     </div>
                                            </div>
                                            <div class="modal-footer"> 
                                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Fermer</button> 
                                                       <button class="btn btn-primary">Envoyer</button>
                                                    </div> 
                                       <?php echo Form::close(); ?>

                                                        </div> 

                                                        
                                                    </div> 
                                                    
                                                </div> 
                                            </div>
                                        </div><!-- /.modal -->

                                                                              <button type="button" class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#con-close-modal">Add <i class="fa fa-plus"></i></button>
                                       
                                                                             
                                        </div>
                                    </div>
                                </div>
                                <table class="table table-bordered table-striped" id="datatable-editable">
                                   
    
                                    <thead>
                                        <tr>
                                            <th>Nom</th>
                                            <th>Prenom</th>
                                            <th>Adresse</th>
                                            <th>Telephone</th>
                                            <th>Email</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                     
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
                                       <tr class="gradeC">
                                            <td><?php echo e($client->nom); ?></td>
                                            <td><?php echo e($client->prenom); ?></td>
                                            <td><?php echo e($client->adresse); ?></td>
                                            <td><?php echo e($client->telephone); ?></td>
                                            <td><?php echo e($client->email); ?></td>
                                             
                                            <td class="actions">
                                                <a href="<?php echo e(route('clients.edit',$client)); ?>" class="hidden on-editing save-row"><i class="fa fa-save"></i></a>
                                                <a href="<?php echo e(route('clients.edit',$client)); ?>" class="hidden on-editing cancel-row"><i class="fa fa-times"></i></a>
                                                <a href="<?php echo e(route('clients.edit',$client)); ?>" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
                                                <a href="#" class="on-default remove-row"><i class="fa fa-trash-o"></i></a>
                                            </td>
                                        </tr> 
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- end: page -->

                        </div> <!-- end Panel -->

                    </div> <!-- container -->
                               
                </div> <!-- content -->

                <footer class="footer text-right">
                    2016 © Moltran.
                </footer>

            </div>
 
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
       
	    <!-- Examples -->
	    <script src="<?php echo e(asset('plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>
	    <script src="<?php echo e(asset('plugins/jquery-datatables-editable/jquery.dataTables.js')); ?>"></script> 
	    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
	    <script src="<?php echo e(asset('pages/datatables.editable.init.js')); ?>"></script>

                <?php endif; ?>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sidebarright', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>













<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>