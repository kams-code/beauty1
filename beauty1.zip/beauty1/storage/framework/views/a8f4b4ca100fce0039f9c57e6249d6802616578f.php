<?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                 <?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="pull-left page-title">General elements</h4>
                                <ol class="breadcrumb pull-right">
                                    <li><a href="#">Moltran</a></li>
                                    <li><a href="#">Forms</a></li>
                                    <li class="active">General elements</li>
                                </ol>
                            </div>
                        </div>

                      <div class="row">
                            <div class="col-md-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading"><h3 class="panel-title">Horizontal form</h3></div>
                                   <div class="panel-body">
                    
                                   <?php echo Form::open(['method' => 'PUT', 'url' => route('organisations.update', $organisation )]); ?>

                          <div class="form-group">
                             <?php echo Form::label('nom','nom'); ?>

                             <?php echo Form::text('nom',$organisation->nom, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('pays','pays'); ?>

                             <?php echo Form::text('pays',$organisation->pays, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('ville','ville'); ?>

                             <?php echo Form::text('ville',$organisation->ville, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('adresse','adresse'); ?>

                             <?php echo Form::text('adresse',$organisation->adresse, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('telephone','telephone'); ?>

                             <?php echo Form::text('telephone',$organisation->telephone    , ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                             <?php echo Form::label('description','description'); ?>

                             <?php echo Form::textarea('description',$organisation->description, ['class' => 'form-control']); ?>

                          </div>
                          <div class="form-group">
                            <label>
                             <?php echo Form::checkbox('online',null,$organisation->online); ?>

                             en ligne?
                             </label> 
                          </div>
                          <button class="btn btn-primary">envoyer</button>
                    <?php echo Form::close(); ?>


                                   </div> <!-- panel-body -->
                                </div> <!-- panel -->
                            </div> <!-- col -->

                        </div> <!-- End row -->


                    </div> <!-- container -->
                               
                </div> <!-- content -->
 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_produits', 'delete_produits')): ?>
                    <footer class="footer text-right">
                    2016 © Moltran.
                </footer>
                <?php endif; ?>
                

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sidebarright', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>













<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>