
@include('partials.nav')
@include('partials.content')
@include('partials.footer')