
@section('footer')
        <div class="container">
            <div class="row">
                <div class=" col-xs-12">
                    <div class="text-center mgbt-xs-10">
                        <a class="btn vd_btn vd_bg-facebook vd_round-btn btn-sm  mgr-10"><i class="fa fa-facebook fa-fw "></i></a>
                        <a class="btn vd_btn vd_bg-googleplus vd_round-btn btn-sm  mgr-10"><i class="fa fa-google-plus fa-fw"></i></a>
                        <a class="btn vd_btn vd_bg-twitter vd_round-btn btn-sm mgr-10"><i class="fa fa-twitter fa-fw "></i></a>
                    </div>
                    <div class="copyright text-center">
                        <p><span class="mgr-10">795 Folsom Ave, Suite 600</span><span class="mgr-10">-</span><span class="mgr-10">San Francisco, CA 94107</span><br/>
                            P: (123) 456-7890
                        </p>
                        Copyright &copy;2018 Iccsoft S.A. All Rights Reserved
                    </div>
                </div>
            </div><!-- row -->
        </div><!-- container -->
    @endsection