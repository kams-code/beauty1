<?php
return ['path' => 'uploads'];